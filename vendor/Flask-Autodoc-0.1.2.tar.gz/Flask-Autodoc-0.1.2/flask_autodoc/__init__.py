__author__ = 'arnaud'

from flask.ext.autodoc.autodoc import Autodoc
